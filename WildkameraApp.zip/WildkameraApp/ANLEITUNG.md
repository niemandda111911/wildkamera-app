# 📱 Wildkamera App – Anleitung (Handy)

## So baust du die APK kostenlos über GitHub Actions

---

## Schritt 1: GitHub-Repository erstellen

1. Öffne **github.com** im Browser
2. Tippe oben rechts auf **„+"** → **„New repository"**
3. Name: `wildkamera-app`
4. Visibility: **Public** (sonst funktioniert Actions nicht kostenlos)
5. ✅ „Add a README file" ankreuzen
6. **„Create repository"** tippen

---

## Schritt 2: Dateien hochladen

### Möglichkeit A: GitHub Mobile App (empfohlen)
1. **GitHub Mobile** aus dem Play Store installieren
2. App öffnen → dein Repository öffnen
3. Tippe auf **„+"** → **„Upload files"**
4. Lade die ZIP-Datei hoch und entpacke sie

### Möglichkeit B: Browser Upload
1. Im Repository auf **„Add file"** → **„Upload files"** tippen
2. Alle Dateien aus der ZIP-Datei einzeln hochladen

**Wichtig:** Die Ordnerstruktur muss exakt so aussehen:
```
wildkamera-app/
├── .github/
│   └── workflows/
│       └── build.yml
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/
│           │   └── com/wildkamera/app/
│           │       ├── MainActivity.java
│           │       ├── WildkameraService.java
│           │       ├── MotionDetector.java
│           │       ├── VideoFileHelper.java
│           │       ├── AppSettings.java
│           │       └── SettingsDialog.java
│           └── res/
│               ├── layout/
│               │   ├── activity_main.xml
│               │   └── dialog_settings.xml
│               └── values/
│                   ├── strings.xml
│                   ├── themes.xml
│                   └── colors.xml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── gradlew
```

---

## Schritt 3: Build automatisch starten

Sobald du Dateien auf den `main`-Branch pushst/hochlädst:
1. Gehe zu **„Actions"** Tab in deinem Repository
2. Du siehst den Workflow **„Build Wildkamera APK"** laufen
3. Warte ca. **3–5 Minuten**
4. Wenn ✅ grün → Klick auf den Build
5. Scrolle zu **„Artifacts"** → **„Wildkamera-APK"** herunterladen

---

## Schritt 4: APK installieren

1. ZIP herunterladen → `app-debug.apk` extrahieren
2. Auf deinem Android-Handy:
   - Einstellungen → Sicherheit → **„Unbekannte Quellen"** erlauben
   - APK-Datei öffnen → **Installieren**

---

## ❓ Fehler beim Build?

- **„Gradle not found"**: Stelle sicher, dass `gradlew` im Root-Ordner liegt
- **„Permission denied"**: Das `build.yml` macht das automatisch (`chmod +x gradlew`)
- **Build fehlgeschlagen**: Im Actions-Tab auf den roten ❌ klicken → Logs lesen

---

## 📋 App-Funktionen

| Funktion | Details |
|---|---|
| Bewegungserkennung | Frame-Differenz-Analyse (einstellbar) |
| Pre-Buffer | Standard 20 Sekunden |
| Nachlaufzeit | Standard 30 Sekunden nach letzter Bewegung |
| Max. Videolänge | Standard 10 Minuten (dann Splitting) |
| Speicherformat | MP4, `Movies/Wildkamera/` |
| Dateiname | `Wildkamera_2025-03-14_003.mp4` |
| Hintergrundmodus | Foreground Service + WakeLock |
| Offline | Vollständig offline |
