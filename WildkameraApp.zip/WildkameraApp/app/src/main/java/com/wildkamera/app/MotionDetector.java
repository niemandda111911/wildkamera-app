package com.wildkamera.app;

import androidx.camera.core.ImageProxy;
import java.nio.ByteBuffer;

/**
 * Detects motion by comparing consecutive grayscale frames.
 * Uses Y-plane (luminance) from YUV_420_888 format.
 */
public class MotionDetector {

    private byte[] previousFrame = null;
    private float sensitivityPercent = 2.0f;  // % of pixels that must change
    private static final int PIXEL_DIFF_THRESHOLD = 30; // per-pixel brightness diff

    public void setSensitivity(float percent) {
        this.sensitivityPercent = percent;
    }

    /**
     * Returns true if motion is detected in this frame.
     * Must be called from the ImageAnalysis executor thread.
     */
    public boolean analyze(ImageProxy image) {
        byte[] current = extractYPlane(image);
        if (current == null) return false;

        boolean motion = false;
        if (previousFrame != null && previousFrame.length == current.length) {
            int totalPixels = current.length;
            int changedPixels = 0;
            for (int i = 0; i < totalPixels; i++) {
                int diff = Math.abs((current[i] & 0xFF) - (previousFrame[i] & 0xFF));
                if (diff > PIXEL_DIFF_THRESHOLD) changedPixels++;
            }
            float changePercent = (changedPixels * 100.0f) / totalPixels;
            motion = changePercent >= sensitivityPercent;
        }

        previousFrame = current;
        return motion;
    }

    private byte[] extractYPlane(ImageProxy image) {
        try {
            ImageProxy.PlaneProxy yPlane = image.getPlanes()[0];
            ByteBuffer buffer = yPlane.getBuffer();
            int rowStride = yPlane.getRowStride();
            int pixelStride = yPlane.getPixelStride();
            int width = image.getWidth();
            int height = image.getHeight();

            // Compact Y values (skip padding)
            byte[] data = new byte[width * height];
            int idx = 0;
            for (int row = 0; row < height; row++) {
                int rowStart = row * rowStride;
                for (int col = 0; col < width; col++) {
                    data[idx++] = buffer.get(rowStart + col * pixelStride);
                }
            }
            return data;
        } catch (Exception e) {
            return null;
        }
    }

    public void reset() {
        previousFrame = null;
    }
}
